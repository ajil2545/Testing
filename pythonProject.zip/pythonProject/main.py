import redis
import paho.mqtt.client as mqtt

# Initialize the Redis cache
redis_cache = redis.StrictRedis(host='127.0.0.1', port=6379, db=0)

# MQTT client for publishing patient information
mqtt_client = mqtt.Client()
mqtt_client.connect("broker.emqx.io", 1883, 60)

# Counter to keep track of the next doctor to assign
counter = 0
# no. of doctors
n = 5


def assign_doctor(patient_id):
    global counter
    # Increment the counter and wrap around if it exceeds n
    counter = (counter + 1) % n
    doctor_topic = "doctor" + str(counter)
    # Publish the patient information to the doctor's topic
    mqtt_client.publish(doctor_topic, patient_id)
    # Store the doctor's topic in the Redis cache for the patient
    redis_cache.set(patient_id, doctor_topic)


def handle_new_patient(patient_id):
    # Check if the patient has visited before
    doctor_topic = redis_cache.get(patient_id)
    if doctor_topic is not None:
        # If the patient has visited before, send to the same doctor
        mqtt_client.publish(doctor_topic, patient_id)
    else:
        # If the patient is new, assign a doctor using round-robin
        assign_doctor(patient_id)


handle_new_patient("Patient3")
assign_doctor("Patient1")
assign_doctor("Patient2")
assign_doctor("Patient1")

"""import random
import time

from paho.mqtt import client as mqtt_client


broker = 'broker.emqx.io'
port = 1883
topic = "python/mqtt"
# generate client ID with pub prefix randomly
client_id = f'python-mqtt-{random.randint(0, 1000)}'


def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client(client_id)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def publish(client):
    msg_count = 0
    while True:
        time.sleep(1)
        msg = f"messages: {msg_count}"
        result = client.publish(topic, msg)
        # result: [0, 1]
        status = result[0]
        if status == 0:
            print(f"Send `{msg}` to topic `{topic}`")
        else:
            print(f"Failed to send message to topic {topic}")
        msg_count += 1


def run():
    client = connect_mqtt()
    client.loop_start()
    publish(client)


if __name__ == '__main__':
    run()
    """
