from datetime import time

import redis
import paho.mqtt.client as mqtt

# Initialize the Redis cache
redis_cache = redis.StrictRedis(host='127.0.0.1', port=6379, db=0)

# MQTT client for subscribing to doctor topics
mqtt_client = mqtt.Client()
mqtt_client.connect("broker.emqx.io", 1883, 60)


def on_message(client, userdata, message):
    patient_id = message.payload.decode()
    doctor_topic = message.topic
    # Store the patient information in the Redis cache
    redis_cache.hmset(patient_id, {"doctor": doctor_topic, "visit_time": time.time()})


n = 5

for i in range(n):
    doctor_topic = "doctor" + str(i)
    mqtt_client.subscribe(doctor_topic)
    mqtt_client.message_callback_add(doctor_topic, on_message)

mqtt_client.loop_start()

"""# python3.6

import random

from paho.mqtt import client as mqtt_client


broker = 'broker.emqx.io'
port = 1883
topic = "python/mqtt"
# generate client ID with pub prefix randomly
client_id = f'python-mqtt-{random.randint(0, 100)}'
# username = 'emqx'
# password = 'public'


def connect_mqtt() -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client(client_id)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def subscribe(client: mqtt_client):
    def on_message(client, userdata, msg):
        print(f"Received `{msg.payload.decode()}` from `{msg.topic}` topic")

    client.subscribe(topic)
    client.on_message = on_message


def run():
    client = connect_mqtt()
    subscribe(client)
    client.loop_forever()


if __name__ == '__main__':
    run()"""
