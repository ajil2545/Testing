from typing import Dict, Optional

from pydantic import BaseModel


class SiteLocation(BaseModel):
    country: Optional[str]
    state: Optional[str]
    city: Optional[str]


class DeviceDetails(BaseModel):
    device_id: str
    device_type: str
    site_name: Optional[str] = None
    site_id: Optional[str] = None
    site_location: SiteLocation
    vendor_name: Optional[str] = None
    customer_name: Optional[str] = None
    mac_address: str
    tags: Optional[list] = None


class DiskUsage(BaseModel):
    data_used: int
    inode_used: int


class IpAddress(BaseModel):
    vpn: str
    public: str


class Version(BaseModel):
    firmware: str
    application: str


class Parameters(BaseModel):
    device_id: str
    disk_usage: Dict[str, DiskUsage]
    ip_address: IpAddress
    version: Version
