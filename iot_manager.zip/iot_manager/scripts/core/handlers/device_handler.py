import logging
from scripts.config import PROJECT_NAME
from scripts.database.mongodb.iot_manager.collections.devices import Devices

logger = logging.getLogger(PROJECT_NAME)


class DeviceHandler:
    def __init__(self, details):
        self.details = details

    def register_device(self) -> dict:
        try:
            Devices().create_device(self.details)
        except Exception as e:
            print(e)
