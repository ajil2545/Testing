import logging
from scripts.config import PROJECT_NAME
logger = logging.getLogger(PROJECT_NAME)


class DeviceHandler:
    def __init__(self, details):
        self.device_id = details.device_id
        self.device_type = details.device_type
        self.site_name = details.site_name
        self.site_id = details.site_id
        self.site_country = details.site_location.country
        self.site_state = details.site_location.state
        self.site_city = details.site_location.city
        self.vendor_name = details.vendor_name
        self.customer_name = details.customer_name
        self.mac_address = details.mac_address
    #
    # def register_device(self) -> dict:
    #     device_details =