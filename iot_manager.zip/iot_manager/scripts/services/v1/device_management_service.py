import logging
from typing import Union

from fastapi import APIRouter, Depends

from scripts.config import PROJECT_NAME
from scripts.constants.api import APIEndPoints
from scripts.core.handlers.device_handler import DeviceHandler
from scripts.schemas.device_schema import (
    SiteLocation,
    DeviceDetails,
    DiskUsage,
    Version,
    IpAddress,
    Parameters,
)

logger = logging.getLogger(PROJECT_NAME)

router = APIRouter(prefix=APIEndPoints.v1)


@router.get("/")
async def root():
    return "Successfully"


@router.post(APIEndPoints.api_create_device)
def create_device(device_details: DeviceDetails):
    """
    Service to create signature for the given payload. The data will be signed
    for the authenticated user.
    """
    try:
        device_handler = DeviceHandler()
        device_data = device_handler.create_device(
            device_id=device_details.device_id,
            device_type=device_details.device_type,
            site_name=device_details.site_name,
            site_id=device_details.site_id,
            vendor_name=device_details.vendor_name,
            customer_name=device_details.customer_name,
            mac_address=device_details.mac_address
        )

        return device_data
    except Exception as e:
        logger.exception(e)
        return "DefaultFailureResponse(error=ErrorMessages.OP_FAILED)"
