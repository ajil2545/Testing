import logging

from fastapi import APIRouter

from scripts.config import PROJECT_NAME
from scripts.constants.api import APIEndPoints
from scripts.core.handlers.device_handler import DeviceHandler
from scripts.schemas.device_schema import (DeviceDetails)

logger = logging.getLogger(PROJECT_NAME)

router = APIRouter(prefix=APIEndPoints.v1)


@router.post(APIEndPoints.api_create_device)
def create_device(device_details: DeviceDetails):
    """
    Service to create signature for the given payload. The data will be signed
    for the authenticated user.
    """
    try:
        device_handler = DeviceHandler(device_details)
        device_handler.register_device()
        return "device_data"
    except Exception as e:
        logger.exception(e)
        return "DefaultFailureResponse(error=ErrorMessages.OP_FAILED)"
