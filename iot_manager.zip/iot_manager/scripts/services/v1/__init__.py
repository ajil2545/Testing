from fastapi import APIRouter


from . import device_management_service
from scripts.constants.api import APIEndPoints

router = APIRouter(prefix=APIEndPoints.api_device_base, tags=["iot manager"])

router.include_router(device_management_service.router)
