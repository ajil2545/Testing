from fastapi import FastAPI

from scripts.services import v1

router = FastAPI()

router.include_router(v1.router)
