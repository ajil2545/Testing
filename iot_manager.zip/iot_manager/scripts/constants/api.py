class _APIEndPoints:
    # versions
    v1 = "/v1"

    # common
    api_create: str = "/create"

    # device management
    api_device_base: str = "/device"
    api_create_device: str = api_create


APIEndPoints = _APIEndPoints()
