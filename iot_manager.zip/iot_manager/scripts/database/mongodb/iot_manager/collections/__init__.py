from scripts.constants.db_constants import DatabaseConstants

collection_devices = DatabaseConstants.collection_devices
