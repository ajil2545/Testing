from typing import Any

from scripts.constants.db_constants import DatabaseConstants
from scripts.database.mongodb import CollectionBaseClass, mongo_client
from scripts.database.mongodb.iot_manager import database
from scripts.schemas.device_schema import DeviceDetails

collection_name = DatabaseConstants.collection_devices


class Devices(CollectionBaseClass):
    def __init__(self, project_id=None):
        super().__init__(
            mongo_client,
            database=database,
            collection=collection_name,
            project_id=project_id
        )

    def create_device(self, device_details: DeviceDetails) -> Any:
        resp = self.insert_one(data=device_details.dict())
        return resp.inserted_id

    def delete_device(self, device_id: str) -> int:
        response = self.delete_one({"device_id": device_id})
        return response.deleted_count

    # def fetch_device(self, device_id: str) -> dict | None:
    #     return self.find_one(query={"device_id": device_id})
