from typing import Literal, Optional

from pydantic import BaseSettings, Field

PROJECT_NAME = "iot_manager"


class _Services(BaseSettings):
    HOST: str = Field(default="127.0.0.1", env="service_host")
    PORT: int = Field(default=8008, env="service_port")
    SECURE_ACCESS: bool = True
    ENABLE_CORS: bool = True
    CORS_URLS: list[str] = ["*.ilens.io", "*.unifytwin.com"]
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS: list[str] = ["GET", "POST", "DELETE", "PUT"]
    CORS_ALLOW_HEADERS: list[str] = ["*"]
    SELF_PROXY: Optional[str] = Field(None, env="IOT_MANAGER_PROXY")
    LOG_LEVEL: Literal["INFO", "DEBUG", "ERROR", "QTRACE"] = "INFO"
    ENABLE_FILE_LOGGING: bool = False
    SW_DOCS_URL: Optional[str] = None
    SW_OPENAPI_URL: Optional[str] = None
    SECURE_COOKIE: bool = True
    ENABLE_RBAC: bool = False


class _Databases(BaseSettings):
    MONGO_URI: Optional[str] = None


Services = _Services()
Databases = _Databases()

__all__ = [
    "PROJECT_NAME",
    "Services",
    "Databases",
]
