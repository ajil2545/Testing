import uvicorn
from fastapi import FastAPI
from scripts.services import router
from scripts.config import PROJECT_NAME, Services
# from scripts.logging.logging import logger
app = FastAPI(**{"hello": "hai"})
# starting the application
if __name__ == "__main__":
    try:
        print("Api for " + PROJECT_NAME)
        uvicorn.run(router, port=8008)
    except Exception as e:
        # logger.error(e)
        print(e)
