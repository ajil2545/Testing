package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;

public class sum extends AppCompatActivity {
    private EditText n1,n2;
    private Button b;
    private TextView r;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sum);
        n1=(EditText) findViewById(R.id.num1);
        n2=(EditText) findViewById(R.id.num2);
        b=(Button) findViewById(R.id.add);
        r=(TextView) findViewById(R.id.result);
        b.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                int num1=Integer.parseInt(n1.getText().toString());
                int num2=Integer.parseInt(n2.getText().toString());
                int num3=num1+num2;
                r.setText(String.valueOf(num3));
            }
        });
    }
}