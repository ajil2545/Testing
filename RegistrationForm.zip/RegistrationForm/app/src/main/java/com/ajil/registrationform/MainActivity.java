package com.ajil.registrationform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button submit;
    private EditText fname,lname,dob,mob,pwd,rpwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fname= (EditText) findViewById(R.id.fname);
        lname= (EditText) findViewById(R.id.lname);
        dob= (EditText) findViewById(R.id.dob);
        mob= (EditText) findViewById(R.id.mob);
        pwd= (EditText) findViewById(R.id.pwd);
        rpwd= (EditText) findViewById(R.id.rpwd);
        submit= (Button) findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fn,ln,db,pswd,rpswd,mobile;
                fn=fname.getText().toString();
                ln=lname.getText().toString();
                db=dob.getText().toString();
                mobile=mob.getText().toString();
                if(fn.length()==0)
                {
                    Toast.makeText(MainActivity.this, "Enter First Name", Toast.LENGTH_SHORT).show();
                }
                if(ln.length()==0)
                {
                    Toast.makeText(MainActivity.this, "Enter Last Name", Toast.LENGTH_SHORT).show();
                }
                if(db.length()==0)
                {
                    Toast.makeText(MainActivity.this, "Enter Date of Birth", Toast.LENGTH_SHORT).show();
                }
                if(mobile.length()==0)
                {
                    Toast.makeText(MainActivity.this, "Enter Mobile Number", Toast.LENGTH_LONG).show();
                }
                if(pwd.length()==0)
                {
                    Toast.makeText(MainActivity.this, "Enter Password", Toast.LENGTH_SHORT).show();
                }
                if(rpwd.length()==0)
                {
                    Toast.makeText(MainActivity.this, "Re-enter Password", Toast.LENGTH_LONG).show();
                }
                if(pwd!=rpwd)
                {
                    Toast.makeText(MainActivity.this, "Password does not match!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}