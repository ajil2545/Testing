from datetime import datetime
from typing import List

import pymongo
from pydantic import BaseModel


class DeviceDetails(BaseModel):
    device_id: str
    software_name: str
    mac_address: str
    site_id: str
    site_name: str
    tags: List[str]
    site_location: dict
    customer: str
    vendor: str


class DeviceParameters(BaseModel):
    device_id: str
    ram_free: str
    ram_total: str
    ram_percent: float
    ram_used: str
    disk: dict
    last_reboot: str
    throttle: str
    io_count: dict
    monitoring_list: str
    vpn_ip: str
    firmware_version: str
    app_version: str
    cpu: dict
    last_received_on: str


# set up the connection to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017")
db1 = client["device_manager"]
existing_collection = db1["mp201a"]

db2 = client["iot_manager"]
device_collection = db2["devices"]
parameters_collection = db2["device_parameters"]

# query the collection to fetch documents
documents = existing_collection.find({}, {"_id": 0})
i = 0
# print the document details
for doc in documents:
    try:
        i += 1
        device_data = DeviceDetails(
            device_id=doc.get("deviceId"),
            software_name=doc.get("softwareName"),
            mac_address=doc.get("mac"),
            site_id=doc.get("site_id"),
            site_name=doc.get("name"),
            tags=doc.get("tags"),
            site_location={
                "country": "",
                "state": "",
                "city": ""
            },
            customer="",
            vendor=""
        )
        parameter_data = DeviceParameters(
            device_id=doc.get("deviceId"),
            ram_free=doc.get("ram_free"),
            ram_total=doc.get("ram_total"),
            ram_percent=doc.get("ram_percent"),
            ram_used=doc.get("ram_used"),
            disk=doc.get("disk"),
            last_reboot=doc.get("last_reboot"),
            throttle=doc.get("throttle"),
            io_count=doc.get("io_count"),
            monitoring_list=doc.get("monitoring_list"),
            vpn_ip=doc.get("vpn_ip"),
            firmware_version=doc.get("version"),
            app_version=doc.get("app_version"),
            cpu=doc.get("cpu"),
            last_received_on=str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )
        device_collection.insert_one(device_data.dict())
        parameters_collection.insert_one(parameter_data.dict())
        print(str(i))
    except Exception as e:
        print(e)
