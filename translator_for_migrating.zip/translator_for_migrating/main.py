from datetime import datetime
from typing import List, Dict

import pymongo
from pydantic import BaseModel, Field


class DeviceDetails(BaseModel):
    device_id: str = Field(default="", description="The ID of the device")
    software_name: str = Field(default="", description="The name of the software running on the device")
    mac_address: str = Field(default="", description="The MAC address of the device")
    site_id: str = Field(default="", description="The ID of the site where the device is located")
    site_name: str = Field(default="", description="The name of the site where the device is located")
    site_location: dict[str, str] = Field(default={"country": "", "state": "", "city": ""},
                                          description="The location of the site where the device is located")
    customer: str = Field(default="", description="The name of the customer that owns the device")
    vendor: str = Field(default="", description="The name of the vendor that supplied the device")
    tags: list[str] = Field(default=[], description="Any tags associated with the device")


class DeviceParameters(BaseModel):
    device_id: str = Field(default="", description="The ID of the device")
    ram_total: str = Field(default="", description="The total amount of RAM on the device")
    ram_percent: float = Field(default=0.00, description="The percentage of RAM used on the device")
    ram_free: str = Field(default="", description="The amount of free RAM on the device")
    ram_used: str = Field(default="", description="The amount of RAM used on the device")
    disk: Dict[str, str] = Field(default={}, description="The details of the disk space on the device")
    last_reboot: str = Field(default="", description="The date and time of the last device reboot")
    last_sync: str = Field(default="", description="The date and time of the last device synchronization")
    throttle: str = Field(default="", description="The throttle status of the device")
    io_count: Dict[str, int] = Field(default={"read_count": 0, "write_count": 0, "read_bytes": 0, "write_bytes": 0,
                                              "read_time": 0, "write_time": 0, "read_merged_count": 0,
                                              "write_merged_count": 0, "busy_time": 0},
                                     description="The input/output count and time for the device")
    public_ip: str = Field(default="", description="The public IP address of the device")
    vpn_ip: str = Field(default="", description="The VPN IP address of the device")
    vpn_connected: str = Field(default="false", description="The status of VPN connection of the device")
    firmware_version: str = Field(default="", description="The firmware version of the device")
    app_version: str = Field(default="", description="The app version of the device")
    monitor_id: str = Field(default="", description="The monitor ID of the device")
    monitoring_list: str = Field(default="", description="The monitoring list of the device")
    cpu: Dict[str, List[int]] = Field(default={"current": "", "overall_usage": "", "cpu_temp": "",
                                               "each_cpu_usage": [0, 0]},
                                      description="The CPU usage and temperature of the device")
    rssi: str = Field(default="", description="The RSSI value of the device")
    cts: int = Field(default=0, description="The CTS value of the device")
    rts: int = Field(default=0, description="The RTS value of the device")
    lts: int = Field(default=0, description="The LTS value of the device")
    ats: int = Field(default=0, description="The ATS value of the device")
    status: str = Field(default="", description="The status of the device")
    clear_sd: bool = Field(default=False, description="The status of clearing the SD card of the device")
    eth_ip: str = Field(default="", description="The Ethernet IP address of the device")
    username: str = Field(default="", description="The username of the device")
    date: str = Field(default="", description="The date of the device")
    network_name: str = Field(default="", description="The network name of the device")
    signal_quality: str = Field(default="", description="The signal quality of the device")
    firmware: Dict[str, str] = Field(default={}, description="The firmware details of the device")
    app: Dict[str, str] = Field(default={}, description="The app details of device")


# set up the connection to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017")
db1 = client["new_iot_devices"]
col = input("Enter the collection name: ")
existing_collection = db1[col]

db2 = client["iot_manager"]
device_collection = db2["devices"]
parameters_collection = db2["device_parameters"]

# query the collection to fetch documents
documents = existing_collection.find({}, {"_id": 0})
i = 0
# print the document details
for doc in documents:
    try:
        i += 1
        ram_percent = doc.get("ram_percent")
        if isinstance(ram_percent, type(None)):
            ram_percent = 0.0
        monitor_list = doc.get("monitor_list")
        print(isinstance(monitor_list, type(None)))
        if isinstance(monitor_list, type(None)):
            monitor_list = ""
        monitor_id = doc.get("monitor_id")
        print(isinstance(monitor_id, type(None)))
        if isinstance(monitor_id, type(None)):
            monitor_id = ""
        ats = doc.get("ats")
        print(isinstance(ats, type(None)))

        if isinstance(ats, type(None)):
            ats = 0
        cts = doc.get("cts")
        print(isinstance(cts, type(None)))
        if isinstance(cts, type(None)):
            cts = 0
        rssi = doc.get("rssi")
        print(isinstance(rssi, type(None)))
        if isinstance(rssi, type(None)):
            rssi = ""
        device_data = DeviceDetails(
            device_id=doc.get("deviceId"),
            software_name=doc.get("softwareName"),
            mac_address=doc.get("mac"),
            site_id=doc.get("site_id"),
            site_name=doc.get("name"),
            tags=doc.get("tags"),
            site_location={
                "country": "",
                "state": "",
                "city": ""
            },
            customer="",
            vendor=""
        )
        parameter_data = DeviceParameters(
            device_id=doc.get("deviceId"),
            ram_free=doc.get("ram_free"),
            ram_total=doc.get("ram_total"),
            ram_percent=doc.get("ram_percent"),
            ram_used=doc.get("ram_used"),
            disk=doc.get("disk"),
            last_reboot=doc.get("last_reboot"),
            last_sync=doc.get("last_sync"),
            throttle=doc.get("throttle"),
            io_count=doc.get("io_count"),
            monitoring_list=monitor_list,
            monitoring_id=monitor_id,
            vpn_ip=doc.get("vpn_ip"),
            public_ip=doc.get("public_ip"),
            vpn_connected=doc.get("vpn_connected"),
            firmware_version=doc.get("version"),
            app_version=doc.get("app_version"),
            cpu=doc.get("cpu"),
            rssi=rssi,
            ats=ats,
            cts=cts
        )
        device_collection.insert_one(device_data.dict())
        parameters_collection.insert_one(parameter_data.dict())
        print(str(i))

    except Exception as e:
        print(e)
    break
