from typing import Optional
from pydantic import BaseModel

class Person(BaseModel):
    name: str
    age: int = 18
    height: Optional[float] = None

person1 = Person(name="John")
print(person1.dict())  # Output: {'name': 'John', 'age': 18, 'height': 1.8}

person2 = Person(name="Mary")
print(person2.dict())  # Output: {'name': 'Mary', 'age': 18, 'height': None}