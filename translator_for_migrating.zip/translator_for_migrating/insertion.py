import pymongo


# set up the connection to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017")
db1 = client["device_manager"]
existing_collection = db1["mp201a"]


i = 0
while i < 6000:
    try:
        data = {
            "mac": "b8:27:eb:f7:98:dc",
            "app_version": "4.6.1",
            "cpu": {
                "high": None,
                "each_cpu_usage": [
                    2.2,
                    3.4,
                    1.1,
                    2.2
                ],
                "overall_usage": "2.2",
                "cpu_temp": "65.0",
                "current": 64.99,
                "critical": None
            },
            "deviceId": "MP201A_"+str(i),
            "disk": {
                "/dev/root": {
                    "data_size": [
                        "/dev/root",
                        "ext4",
                        "13G",
                        "5.2G",
                        "6.8G",
                        "44%",
                        "/"
                    ],
                    "inode_size": [
                        "/dev/root",
                        "ext4",
                        "829K",
                        "524K",
                        "306K",
                        "64%",
                        "/"
                    ]
                },
                "/dev/mmcblk0p6": {
                    "data_size": [
                        "/dev/mmcblk0p6",
                        "vfat",
                        "68M",
                        "22M",
                        "47M",
                        "32%",
                        "/boot"
                    ],
                    "inode_size": [
                        "/dev/mmcblk0p6",
                        "vfat",
                        "0",
                        "0",
                        "0",
                        "-",
                        "/boot"
                    ]
                }
            },
            "io_count": {
                "write_bytes": 16724992,
                "read_count": 4693,
                "write_count": 1841,
                "read_time": 149870,
                "read_bytes": 138127872,
                "busy_time": 509590,
                "read_merged_count": 6288,
                "write_time": 6508610,
                "write_merged_count": 1986
            },
            "last_reboot": "2023-02-25 09:48:40",
            "last_sync": "2023-02-25T10:30:17Z",
            "name": "Dubai Municipality Station G",
            "public_ip": "31.218.91.47",
            "ram_free": "685644",
            "ram_percent": 10.4,
            "ram_total": "949452",
            "ram_used": "98728",
            "site_id": "site_202_cpcb",
            "softwareName": "MP201A",
            "tags": [
                ""
            ],
            "throttle": "0x0",
            "version": "4.6.1",
            "vpn_connected": False,
            "vpn_ip": "10.8.0.8",
            "monitoring_list": "DM_G"
        }
        res = existing_collection.insert_one(data)
        i += 1
        print(str(res.inserted_id) + " " + str(i))
    except Exception as e:
        print(e)
