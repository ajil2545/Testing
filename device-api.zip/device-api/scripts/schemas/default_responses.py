from typing import Any, Optional

from pydantic import BaseModel


class DefaultResponse(BaseModel):
    status: bool = True
    message: Optional[str]
    data: Optional[Any]


class DefaultFailureResponse(DefaultResponse):
    status: bool = False
    error: Any
