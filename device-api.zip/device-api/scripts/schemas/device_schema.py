import datetime
from typing import Dict, Optional, List, Union
from datetime import datetime
from pydantic import BaseModel, Field


# class SiteLocation(BaseModel):
#     country: Optional[str]
#     state: Optional[str]
#     city: Optional[str]
#
#
# class DeviceDetails(BaseModel):
#     device_id: str
#     device_type: str
#     site_name: Optional[str] = None
#     site_id: Optional[str] = None
#     site_location: SiteLocation
#     vendor_name: Optional[str] = None
#     customer_name: Optional[str] = None
#     mac_address: str
#     tags: Optional[list] = None

#
# class DiskUsage(BaseModel):
#     data_used: int
#     inode_used: int
#
#
# class IpAddress(BaseModel):
#     vpn: str
#     public: str
#
#
# class Version(BaseModel):
#     firmware: str
#     application: str
#
#
# class Parameters(BaseModel):
#     device_id: str
#     disk_usage: Dict[str, DiskUsage]
#     ip_address: IpAddress
#     version: Version


class DiskDataSize(BaseModel):
    values: List[str]


class DiskInodeSize(BaseModel):
    values: List[str]


# class DiskInfo(BaseModel):
#     data_size: List[str]
#     inode_size: List[str]
#
#
# class DiskPartition(BaseModel):
#     partition_name: str
#     disk_info: DiskInfo
#
#
# class DiskPartitionMongoDB(DiskPartition):
#     partition_name: str
#     disk_info: DiskInfo
#
#     class Config:
#         allow_population_by_field_name = True
#         json_encoders = {ObjectId: str}
class Disk(BaseModel):
    # disks: dict[str, dict[str, Union[DiskDataSize, DiskInodeSize]]]
    disks: Optional[dict]


class Cpu(BaseModel):
    current: str
    overall_usage: float
    cpu_temp: float
    each_cpu_usage: List[float]


class IoCount(BaseModel):
    read_bytes: int
    read_count: int
    read_merged_count: int
    read_time: int
    write_bytes: int
    write_count: int
    write_merged_count: int
    write_time: int
    busy_time: int


# class ExampleModel(BaseModel):
#     ram_free: str
#     tags: List[str]
#     site_id: str
#     softwareName: str
#     mac: str
#     deviceId: str
#     ram_total: str
#     disk: Disk
#     ram_percent: float
#     last_reboot: str
#     throttle: str
#     name: str
#     io_count: IoCount
#     monitoring_list: str
#     vpn_ip: str
#     version: str
#     ram_used: str
#     app_version: str
#     cpu: Cpu


class SiteDetails(BaseModel):
    country: str
    state: str
    city: str


class DevicePurchase(BaseModel):
    customer_name: str
    vendor_name: str
    site_location: SiteDetails


class DeviceDetails(BaseModel):
    device_id: str
    software_name: str
    mac_address: str
    site_id: str
    site_name: str
    tags: List[str]


class DeviceParameters(BaseModel):
    device_id: str
    ram_free: str
    ram_total: str
    ram_percent: float
    ram_used: str
    disk: dict
    last_reboot: str
    throttle: str
    io_count: dict
    monitoring_list: str
    vpn_ip: str
    firmware_version: str
    app_version: str
    cpu: dict

