class _APIEndPoints:
    # versions
    v1 = "/v1"

    # common
    api_create: str = "/create"
    api_get: str = "/get"
    api_response: str = "/response_data"

    # device management
    api_device_base: str = "/device"
    api_create_device: str = api_create
    api_get_device: str = api_get+"/{device_id}"
    api_heart_beat_data: str = api_response


APIEndPoints = _APIEndPoints()
