class DatabaseConstants:
    # Databases
    db_iot_manager = "iot_manager"

    # Collections
    collection_devices = "devices"
    collection_parameters = "device_parameters"
    collection_newly_added_devices = "newly_added_devices"
