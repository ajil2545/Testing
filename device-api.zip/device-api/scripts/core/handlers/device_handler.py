import logging
from scripts.config import PROJECT_NAME
from scripts.database.mongodb.iot_manager.collections.devices import Devices
from scripts.database.mongodb.iot_manager.collections.newly_added_devices import NewDevices
from scripts.database.mongodb.iot_manager.collections.parameters import Parameters
from scripts.schemas.device_schema import DeviceDetails, DeviceParameters

logger = logging.getLogger(PROJECT_NAME)

devices = Devices()
parameters = Parameters()
new_devices = NewDevices()


class DeviceHandler:
    @staticmethod
    def register_device(details) -> dict:
        try:
            result = devices.create_device(details)
            return result
        except Exception as e:
            logger.exception(e)

    @staticmethod
    def check_device(response_data) -> dict:
        try:
            device_data = DeviceDetails(
                device_id=response_data["deviceId"],
                software_name=response_data["softwareName"],
                mac_address=response_data["mac"],
                site_id=response_data["site_id"],
                site_name=response_data["name"],
                tags=response_data["tags"]
            )
            parameter_data = DeviceParameters(
                device_id=response_data["deviceId"],
                ram_free=response_data["ram_free"],
                ram_total=response_data["ram_total"],
                ram_percent=response_data["ram_percent"],
                ram_used=response_data["ram_used"],
                disk=response_data["disk"],
                last_reboot=response_data["last_reboot"],
                throttle=response_data["throttle"],
                io_count=response_data["io_count"],
                monitoring_list=response_data["monitoring_list"],
                vpn_ip=response_data["vpn_ip"],
                firmware_version=response_data["version"],
                app_version=response_data["app_version"],
                cpu=response_data["cpu"]
            )
            status = devices.check_device_id(device_data.device_id, device_data.site_id)
            if status:
                update_device_status = devices.update_device(device_data)
                update_parameters_status = parameters.update_parameters(parameter_data)

            else:
                registration_status = devices.create_device(device_data)
                newly_added_device_status = new_devices.check_new_device(device_data)
                parameters_status = parameters.add_parameters(parameter_data)

        except Exception as e:
            logger.exception(e)

    @staticmethod
    def fetch_device_details(device_id) -> dict:
        try:
            result = devices.fetch_device(device_id)
            return result
        except Exception as e:
            logger.exception(e)
