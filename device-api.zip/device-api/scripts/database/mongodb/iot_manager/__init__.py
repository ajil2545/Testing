from scripts.constants.db_constants import DatabaseConstants

database = DatabaseConstants.db_iot_manager
