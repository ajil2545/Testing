from __future__ import annotations

import logging
import uuid
from typing import Any
from scripts.constants.db_constants import DatabaseConstants
from scripts.database.mongodb import CollectionBaseClass, mongo_client
from scripts.database.mongodb.iot_manager import database
from scripts.schemas.device_schema import DeviceDetails

collection_name = DatabaseConstants.collection_devices


class Devices(CollectionBaseClass):
    def __init__(self, project_id=None):
        super().__init__(
            mongo_client,
            database=database,
            collection=collection_name,
            project_id=project_id
        )

    def check_device_id(self, device_id, site_id) -> Any:
        if self.find_one({'device_id': device_id}):
            # Device with device_id already exists
            return True
        else:
            # No Device with device_id exists in the DB
            return False

    def create_device(self, device_details: DeviceDetails) -> Any:
        try:
            if not  device_details.device_id:
                device_details.device_id=str(uuid.uuid4())
            resp = self.insert_one(data=device_details.dict())


            return resp.inserted_id
        except Exception as e:
            logging.exception(e)

    def update_device(self, device_details: DeviceDetails) -> Any:
        try:
            resp = self.update_one(query={"device_id": device_details.device_id},
                                   data={"site_id": device_details.site_id,
                                         "site_name": device_details.site_name,
                                         "mac_address": device_details.mac_address,
                                         "software_name": device_details.software_name,
                                         "tags": device_details.tags
                                         })
            if resp.matched_count == 1:
                return True
            return False
        except Exception as e:
            logging.exception(e)

    def delete_device(self, device_id: str) -> int:
        response = self.delete_one({"device_id": device_id})
        return response.deleted_count

    def fetch_device(self, device_id: str) -> dict:
        return self.find_one(query={"device_id": device_id})
