from __future__ import annotations

import logging
from typing import Any
from datetime import datetime
from scripts.constants.db_constants import DatabaseConstants
from scripts.database.mongodb import CollectionBaseClass, mongo_client
from scripts.database.mongodb.iot_manager import database
from scripts.schemas.device_schema import DeviceDetails

collection_name = DatabaseConstants.collection_newly_added_devices


class NewDevices(CollectionBaseClass):
    def __init__(self, project_id=None):
        super().__init__(
            mongo_client,
            database=database,
            collection=collection_name,
            project_id=project_id
        )

    def check_new_device(self, device_details: DeviceDetails) -> Any:
        try:
            if self.find_one(query={"device_id": device_details.device_id}):
                return "Already have the device details"
            else:
                device_data = {
                    "device_id": device_details.device_id,
                    "site_id": device_details.site_id,
                    "site_name": device_details.site_name,
                    "registered_date": str(datetime.now())
                }
                resp = self.insert_one(data=device_data)
                return resp.inserted_id
        except Exception as e:
            logging.exception(e)

    def fetch_device(self, device_id: str) -> dict:
        return self.find_one(query={"device_id": device_id})
