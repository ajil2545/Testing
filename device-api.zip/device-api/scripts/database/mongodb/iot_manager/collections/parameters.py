from __future__ import annotations
import logging
from typing import Any
from scripts.constants.db_constants import DatabaseConstants
from scripts.database.mongodb import CollectionBaseClass, mongo_client
from scripts.database.mongodb.iot_manager import database
from scripts.schemas.device_schema import DeviceParameters

collection_name = DatabaseConstants.collection_parameters


class Parameters(CollectionBaseClass):
    def __init__(self, project_id=None):
        super().__init__(
            mongo_client,
            database=database,
            collection=collection_name,
            project_id=project_id
        )

    def add_parameters(self, device_parameters: DeviceParameters) -> Any:
        try:
            resp = self.insert_one(data=device_parameters.dict())
            return resp.inserted_id
        except Exception as e:
            logging.exception(e)

    def update_parameters(self, device_parameters: DeviceParameters) -> Any:
        resp = self.update_one(query={"device_id": device_parameters.device_id},
                               data={"ram_free": device_parameters.ram_free,
                                     "ram_total": device_parameters.ram_total,
                                     "ram_percent": device_parameters.ram_percent,
                                     "ram_used": device_parameters.ram_used,
                                     "disk": device_parameters.disk,
                                     "last_reboot": device_parameters.last_reboot,
                                     "throttle": device_parameters.throttle,
                                     "io_count": device_parameters.io_count,
                                     "monitoring_list": device_parameters.monitoring_list,
                                     "vpn_ip": device_parameters.vpn_ip,
                                     "firmware_version": device_parameters.firmware_version,
                                     "app_version": device_parameters.app_version,
                                     "cpu": device_parameters.cpu}
                               )
        if resp.matched_count == 1:
            return True
        return False
