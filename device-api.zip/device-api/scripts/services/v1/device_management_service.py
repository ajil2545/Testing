import logging

from fastapi import APIRouter

from scripts.config import PROJECT_NAME
from scripts.constants.api import APIEndPoints
from scripts.core.handlers.device_handler import DeviceHandler
from scripts.errors import ErrorMessages
from scripts.schemas import DefaultFailureResponse, DefaultResponse

logger = logging.getLogger(PROJECT_NAME)

router = APIRouter()

device_handler = DeviceHandler()

#
# @router.post(APIEndPoints.api_create_device)
# def create_device(device_details: DeviceDetails):
#     """
#     Service to register a device
#     """
#     try:
#         result = device_handler.register_device(device_details)
#         if result is None:
#             return DefaultFailureResponse(error=ErrorMessages.OP_FAILED)
#         else:
#             return DefaultResponse(
#                 message="Device created successfully!",
#                 data=device_details
#             )
#     except Exception as e:
#         logger.exception(e)
#         return DefaultFailureResponse(error=ErrorMessages.DEVICE_CREATION_FAILED)
#


@router.get(APIEndPoints.api_get_device)
def get_device(device_id: str):
    """
    :param device_id:
    :return:
    """
    try:
        result = device_handler.fetch_device_details(device_id)
        if result:
            return DefaultResponse(
                message="Device details fetched successfully!",
                data=result
            )
        else:
            return DefaultFailureResponse(error=ErrorMessages.INVALID_DEVICE_ID)

    except Exception as e:
        logger.exception(e)
        return DefaultFailureResponse(error=ErrorMessages.OP_FAILED)


@router.post(APIEndPoints.api_response)
# request will get all details from device
async def heart_beat(response_data: dict):
    try:
        device_handler.check_device(response_data)
        return DefaultResponse(
                message="Device details updated successfully!"
            )
    except Exception as e:
        logger.exception(e)
        return DefaultFailureResponse(error=ErrorMessages.RES_FAILED)
