import uvicorn
from fastapi import FastAPI
from scripts import services
from scripts.config import PROJECT_NAME, Services

app = FastAPI()
app.include_router(services.router)
# starting the application
if __name__ == "__main__":
    try:
        print("Starting " + PROJECT_NAME)
        uvicorn.run(services.router, host=Services.HOST, port=Services.PORT)
    except Exception as e:
        # logger.error(e)
        print(e)
